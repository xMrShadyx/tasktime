let state;let lang='bg';let tab='today';const $=id=>document.getElementById(id);
const W={bg:{tabs:{today:'Днес',stats:'Статистика',shifts:'Смени',review:'За преглед',history:'История',settings:'Настройки'},
status:{in:'На смяна',break:'В почивка',out:'Извън смяна'},
kpi:['Завършени задачи','Време в задачи','Средно на задача','Работено време'],
todayTypes:'Задачи днес по тип',shiftNow:'Текуща смяна',recent:'Последни задачи',noShift:'В момента не си на смяна.',
started:'Начало',planned:'Планиран край',worked:'Работено',breaks:'Почивки',overtime:'След планирания край',ended:'Край',open:'продължава',
otYes:'overtime потвърден',otNo:'overtime не е потвърден',
presets:[['today','Днес'],['week','7 дни'],['month','Този месец']],from:'От',to:'До',csv:'Свали CSV',heads:['Тип','Брой','Най-бърза','Най-бавна','Средно','Общо'],total:'Общо',
statsNote:'Броят се само завършените задачи, по датата на завършване. Времето е ч:мм:сс.',
reviewNote:'TaskTime не е сигурен, че тези задачи са приключили нормално. Потвърди ги, за да влязат в статистиката, или ги изключи.',
search:'Търси по тип, лига или ID…',hFilters:[['all','Всички'],['normal','Обикновени'],['postqa','Post QA'],['review','За преглед']],hSize:'На страница',hInfo:(a,b,n)=>n?`Показани ${a}–${b} от ${n}`:'',hDay:(n,t)=>`${n} ${n===1?'задача':'задачи'} · ${t}`,prev:'‹ Предишна',next:'Следваща ›',days:['Неделя','Понеделник','Вторник','Сряда','Четвъртък','Петък','Събота'],
reasons:{'next-task':'мина към следваща задача','left-task':'напусна задачата','tab-closed':'затворен таб','tab-conflict':'отворена в друг таб'},
noFinish:'без Finish / Clear Samples',gaps:n=>`${n} прекъсвания`,
confirm:'Потвърди',exclude:'Изключи',status_:{active:'Активна',completed:'Завършена',review:'За преглед',excluded:'Изключена'},corrected:'ръчно',
alertTitle:'Сигнал за нова задача',alertNote:'🟢 при нова задача, докато не гледаш Redstone · 🟠 при „Are you still active?“ · 🔴 когато остават 5 секунди.',alertSound:'Звуков сигнал',alertVolume:'Сила на звука',alertTest:'Пробвай звука',alertNotify:'Известие в системата',notifyTip:'Освен звука, при нова задача ще излиза и изскачащо съобщение в ъгъла на екрана (като известията от Windows), с лигата и типа на задачата. Клик върху него те връща директно в таба с Redstone. Полезно, ако работиш с изключен звук. При включване браузърът ще поиска разрешение.',alertDenied:'Браузърът не позволи известия.',
dataTitle:'Твоите данни',dataNote:'Записите стоят само в този браузър. Ако премахнеш добавката, изтриеш или преместиш папката ѝ, те се губят. Първо свали архив, а след новата инсталация го възстанови.',backup:'Свали архив (JSON)',restore:'Възстанови от архив',restoreAsk:'Записите в отчета ще бъдат заменени с тези от архива. Продължи?',restored:(t,s)=>`Възстановени: ${t} задачи, ${s} смени.`,badBackup:'Файлът не е валиден архив на TaskTime.',
q:{plan:'До колко часа е смяната ти?',out:'Почивка или приключваш работа?',over:'Планираната смяна приключи. Още ли работиш?',reminder:'Направи Clock Out в Ximble, за да се потвърди краят.'},
upd:v=>`Има нова версия ${v}`,finUpd:'Довърши обновяването',finishHow:'Файловете са сменени, но браузърът още ползва част от старата версия. Отвори страницата с разширения и натисни ↻ Reload на TaskTime.',finishGo:'Отвори разширенията',updHow:'Свали я от сайта и я разархивирай върху сегашната папка (замени файловете). TaskTime ще се презареди сам до минута — записите ти остават.',updGo:'Към сайта',cfgTitle:'Лиги и типове задачи',cfgNote:'TaskTime разпознава задачите по тези списъци. Ако Redstone добави нова лига или нов тип задача, добави го тук — работи веднага, без нова версия.',cfgGroups:{types:['Типове задачи','Част от адреса след лигата, напр. reid в /global-tasks/uefa/reid/…'],leagues:['Лиги','Нужни са само за адреси без /global-tasks/ — там всяка лига се разпознава сама.'],pages:['Страници, които НЕ са задачи','Напр. next — екранът „no tasks available, waiting“.']},cfgLegend:['вградени','от сайта','твои'],cfgAdd:'Добави',cfgPh:'напр. shot',cfgBad:'Само малки латински букви, цифри, - и _.',cfgUnknown:t=>`TaskTime видя непознат тип задача „${t}“. Засега тези задачи се записват като other.`,cfgAddType:'Добави като тип',cfgHide:'Скрий',verTitle:'Версия',verNote:v=>`Инсталирана е версия ${v}. TaskTime проверява за нова версия няколко пъти на ден.`,verCheck:'Провери сега',openExt:'Отвори разширенията',verHow:'Как се обновява',verSteps:['Свали новата версия от сайта.','Разархивирай я <b>върху същата папка</b> и избери <b>Replace</b> (замени файловете).','Натисни бутона <b>„Отвори разширенията“</b> по-долу (или напиши <code>chrome://extensions</code> / <code>opera://extensions</code> в адресната лента).','Намери картата на <b>TaskTime</b> и натисни <b>↻</b> (Reload / Презареди).','Готово — тук трябва да пише новата версия. Записите ти остават.'],folderTitle:'Папка на добавката',folderNote:'TaskTime се зарежда от тази папка. Не я трий и не я мести — иначе добавката спира и записите се губят.',folderNone:'Още не е въведена. Браузърът не позволява на добавката сама да види пътя — копирай го веднъж по стъпките по-долу.',folderPh:'напр. C:\\Users\\Име\\Documents\\TaskTime',folderSave:'Запази',folderCopy:'Копирай',folderSteps:['Натисни <b>„Отвори разширенията“</b> в раздела „Версия“ по-горе.','Отваря се страницата с подробности за TaskTime. Слез до <b>„Source“ / „Източник“</b> — до <b>„Loaded from“</b> (Заредено от) е пътят до папката.','Копирай пътя, постави го в полето по-горе и натисни „Запази“.'],verLatest:'Имаш последната версия.',save:'Запази',break:'Почивка',finish:'Приключвам',ot:'Продължавам с overtime',endDate:'Край',empty:'Още няма записи.',saved:'Запазено',invalid:'Избери валиден период.'},
en:{tabs:{today:'Today',stats:'Statistics',shifts:'Shifts',review:'To review',history:'History',settings:'Settings'},
status:{in:'On shift',break:'On a break',out:'Off shift'},
kpi:['Completed tasks','Time in tasks','Average per task','Time worked'],
todayTypes:'Today’s tasks by type',shiftNow:'Current shift',recent:'Recent tasks',noShift:'You are not on shift right now.',
started:'Start',planned:'Planned end',worked:'Worked',breaks:'Breaks',overtime:'After planned end',ended:'End',open:'ongoing',
otYes:'overtime confirmed',otNo:'overtime not confirmed',
presets:[['today','Today'],['week','7 days'],['month','This month']],from:'From',to:'To',csv:'Download CSV',heads:['Type','Count','Fastest','Slowest','Average','Total'],total:'Total',
statsNote:'Only completed tasks count, by completion date. Time is h:mm:ss.',
reviewNote:'TaskTime is not sure these tasks finished normally. Confirm them to include them in statistics, or exclude them.',
search:'Search by type, league or ID…',hFilters:[['all','All'],['normal','Regular'],['postqa','Post QA'],['review','To review']],hSize:'Per page',hInfo:(a,b,n)=>n?`Showing ${a}–${b} of ${n}`:'',hDay:(n,t)=>`${n} ${n===1?'task':'tasks'} · ${t}`,prev:'‹ Previous',next:'Next ›',days:['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'],
reasons:{'next-task':'moved to next task','left-task':'left the task','tab-closed':'tab closed','tab-conflict':'opened in another tab'},
noFinish:'no Finish / Clear Samples',gaps:n=>`${n} interruptions`,
confirm:'Confirm',exclude:'Exclude',status_:{active:'Active',completed:'Completed',review:'To review',excluded:'Excluded'},corrected:'manual',
alertTitle:'New task alert',alertNote:'🟢 on a new task while you are not looking at Redstone · 🟠 on “Are you still active?” · 🔴 when 5 seconds are left.',alertSound:'Sound alert',alertVolume:'Volume',alertTest:'Test sound',alertNotify:'System notification',notifyTip:'Besides the sound, a new task also shows a pop-up in the screen corner (like Windows notifications) with the task league and type. Clicking it takes you straight back to the Redstone tab. Handy if you work with sound off. The browser asks for permission when you turn it on.',alertDenied:'The browser did not allow notifications.',
dataTitle:'Your data',dataNote:'Records are stored only in this browser. Removing the extension, or deleting or moving its folder, loses them. Download a backup first and restore it after reinstalling.',backup:'Download backup (JSON)',restore:'Restore from backup',restoreAsk:'Your report will be replaced with the records from the backup. Continue?',restored:(t,s)=>`Restored: ${t} tasks, ${s} shifts.`,badBackup:'This file is not a valid TaskTime backup.',
q:{plan:'What time does your shift end?',out:'Taking a break or finishing work?',over:'Your planned shift has ended. Still working?',reminder:'Clock Out in Ximble to confirm the end.'},
upd:v=>`New version ${v} is available`,finUpd:'Finish updating',finishHow:'The files were replaced, but the browser still runs part of the old version. Open the extensions page and press ↻ Reload on TaskTime.',finishGo:'Open extensions',updHow:'Download it from the site and extract it over the current folder (replace the files). TaskTime reloads itself within a minute — your records stay.',updGo:'Go to site',cfgTitle:'Leagues and task types',cfgNote:'TaskTime recognises tasks using these lists. If Redstone adds a new league or task type, add it here — it works immediately, no new version needed.',cfgGroups:{types:['Task types','The part of the address after the league, e.g. reid in /global-tasks/uefa/reid/…'],leagues:['Leagues','Only needed for addresses without /global-tasks/ — there any league is recognised automatically.'],pages:['Pages that are NOT tasks','E.g. next — the “no tasks available, waiting” screen.']},cfgLegend:['built-in','from the site','yours'],cfgAdd:'Add',cfgPh:'e.g. shot',cfgBad:'Only lowercase Latin letters, digits, - and _.',cfgUnknown:t=>`TaskTime saw an unknown task type “${t}”. For now these tasks are recorded as other.`,cfgAddType:'Add as a type',cfgHide:'Hide',verTitle:'Version',verNote:v=>`Version ${v} is installed. TaskTime checks for a new version a few times a day.`,verCheck:'Check now',openExt:'Open extensions',verHow:'How to update',verSteps:['Download the new version from the site.','Extract it <b>over the same folder</b> and choose <b>Replace</b>.','Press <b>“Open extensions”</b> below (or type <code>chrome://extensions</code> / <code>opera://extensions</code> in the address bar).','Find the <b>TaskTime</b> card and press <b>↻</b> (Reload).','Done — this section should show the new version. Your records stay.'],folderTitle:'Extension folder',folderNote:'TaskTime is loaded from this folder. Do not delete or move it — the extension would stop and your records would be lost.',folderNone:'Not set yet. The browser does not let the extension see its own path — copy it once using the steps below.',folderPh:'e.g. C:\\Users\\Name\\Documents\\TaskTime',folderSave:'Save',folderCopy:'Copy',folderSteps:['Press <b>“Open extensions”</b> in the Version section above.','The TaskTime details page opens. Scroll to <b>“Source”</b> — next to <b>“Loaded from”</b> is the folder path.','Copy the path, paste it into the field above and press “Save”.'],verLatest:'You have the latest version.',save:'Save',break:'Take a break',finish:'Finish work',ot:'Continue with overtime',endDate:'End',empty:'No records yet.',saved:'Saved',invalid:'Choose a valid date range.'}};
const TABS=['today','stats','shifts','review','history','settings'];
const sec=ms=>Math.max(0,Math.round((ms||0)/1000));
const fmt=ms=>ms==null?'—':`${Math.floor(sec(ms)/3600)}:${String(Math.floor(sec(ms)/60)%60).padStart(2,'0')}:${String(sec(ms)%60).padStart(2,'0')}`;
const short=ms=>{if(ms==null)return '—';const s=sec(ms),h=Math.floor(s/3600),m=Math.floor(s/60)%60;return h?`${h}${lang==='bg'?'ч':'h'} ${m}${lang==='bg'?'м':'m'}`:`${m}:${String(s%60).padStart(2,'0')}`};
const loc=()=>lang==='bg'?'bg-BG':'en-GB';
const dt=ms=>ms?new Date(ms).toLocaleString(loc(),{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}):'—';
const hm=ms=>ms?new Date(ms).toLocaleTimeString(loc(),{hour:'2-digit',minute:'2-digit'}):'—';
const el=(tag,props={},...kids)=>{const e=document.createElement(tag);for(const [k,v] of Object.entries(props)){if(k==='class')e.className=v;else if(k.startsWith('on'))e.addEventListener(k.slice(2),v);else e[k]=v}for(const k of kids.flat())if(k!=null)e.append(k);return e};
async function request(m){const r=await chrome.runtime.sendMessage(m);if(r?.error)throw Error(r.error);return r.result}
let msgTimer;function message(t){$('message').textContent=t;clearTimeout(msgTimer);msgTimer=setTimeout(()=>$('message').textContent='',4000)}
async function mutate(m){try{await request(m);await load();message(W[lang].saved)}catch(e){message(e.message)}}
function download(name,text,type){const u=URL.createObjectURL(new Blob([text],{type}));el('a',{href:u,download:name}).click();setTimeout(()=>URL.revokeObjectURL(u),1000)}
const today=()=>TaskTime.dateKey(Date.now());
const shiftOf=s=>s.shifts.find(x=>x.id===s.shift);
const sumIntervals=(xs,from=0)=>xs.reduce((a,i)=>a+Math.max(0,(i.end||Date.now())-Math.max(i.start,from)),0);
function clockState(){const sh=shiftOf(state);if(state.clock==='in')return 'in';if(sh&&!sh.end&&sh.breaks.some(b=>!b.end))return 'break';return 'out'}

function drawChrome(){const w=W[lang];document.documentElement.lang=lang;document.querySelectorAll('#lang button').forEach(b=>b.setAttribute('aria-checked',String(b.dataset.lang===lang)));
 const cs=clockState();$('status').className='status '+cs;$('status').replaceChildren(el('i'),w.status[cs]);
 const nReview=state.tasks.filter(t=>t.status==='review').length;
 $('tabs').replaceChildren(...TABS.map(t=>el('button',{role:'tab',ariaSelected:String(t===tab),onclick:()=>{tab=t;try{localStorage.setItem('tt-tab',t)}catch{}draw()}},w.tabs[t],t==='review'&&nReview?el('span',{class:'count',textContent:nReview}):null)));
 document.querySelectorAll('section[data-tab]').forEach(s=>s.classList.toggle('on',s.dataset.tab===tab))}

function drawQuestions(){const w=W[lang];const box=$('questions');if(box.contains(document.activeElement))return;box.replaceChildren();
 for(const p of state.prompts){const q=el('div',{class:'question'},el('h3',{textContent:w.q[{plan:'plan','clock-out':'out',overtime:'over',reminder:'reminder'}[p.kind]]}),el('p',{textContent:dt(p.at)}));
  const btn=(text,value,ghost)=>q.append(el('button',{class:ghost?'ghost':'',textContent:text,onclick:()=>mutate({kind:'answer',id:p.id,value:typeof value==='function'?value():value})}));
  if(p.kind==='plan'){const input=el('input',{type:'time'});const prev=el('span',{class:'hint'});input.oninput=()=>{try{prev.textContent=w.endDate+': '+dt(TaskTime.planTime(p.at,input.value))}catch{prev.textContent=''}};q.append(input);btn(w.save,()=>input.value);q.append(prev)}
  if(p.kind==='clock-out'){btn(w.break,'break');btn(w.finish,'finish',true)}
  if(p.kind==='overtime'){btn(w.ot,'overtime');btn(w.finish,'finish',true)}
  box.append(q)}}

function taskItem(t,actions){const w=W[lang];const why=[];if(t.reason&&t.status!=='completed')why.push(w.reasons[t.reason]||t.reason);if(!t.finishAt&&t.status==='review')why.push(w.noFinish);if(t.gaps?.length)why.push(w.gaps(t.gaps.length));
 const it=el('div',{class:'item'},el('div',{class:'main'},el('div',{},el('b',{textContent:t.type}),' ',el('span',{class:'chip '+t.status,textContent:w.status_[t.status]+(t.corrected?' · '+w.corrected:'')}),t.postQa?' ':null,t.postQa?el('span',{class:'chip postqa',textContent:'Post QA'}):null),el('small',{textContent:`${t.league||'football'} · ${dt(t.start)} → ${t.end?hm(t.end):'…'}${why.length?' · '+why.join(', '):''}`,title:t.id})),el('span',{class:'dur',textContent:fmt(t.observedMs)}));
 if(actions){it.append(el('button',{textContent:w.confirm,onclick:()=>mutate({kind:'correct-task',key:t.key,status:'completed'})}),el('button',{class:'danger',textContent:w.exclude,onclick:()=>mutate({kind:'correct-task',key:t.key,status:'excluded'})}))}
 return it}
const empty=()=>el('div',{class:'empty',textContent:W[lang].empty});

function drawToday(){const w=W[lang];const k=today();const done=state.tasks.filter(t=>t.status==='completed'&&t.end&&TaskTime.dateKey(t.end)===k);const total=done.reduce((a,t)=>a+t.observedMs,0);
 const sh=shiftOf(state)||[...state.shifts].reverse().find(s=>TaskTime.dateKey(s.start)===k);const worked=sh?sumIntervals(sh.intervals):null;
 $('kpis').replaceChildren(...[[done.length,w.kpi[0]],[short(total),w.kpi[1]],[done.length?short(total/done.length):'—',w.kpi[2]],[worked==null?'—':short(worked),w.kpi[3]]].map(([v,l])=>el('div',{class:'kpi'},el('b',{textContent:v}),el('span',{textContent:l}))));
 $('todayTypesTitle').textContent=w.todayTypes;const by={};for(const t of done)by[t.type]=(by[t.type]||0)+1;const max=Math.max(1,...Object.values(by));
 $('todayTypes').replaceChildren(...(Object.keys(by).length?Object.entries(by).sort((a,b)=>b[1]-a[1]).map(([type,n])=>el('div',{class:'bar'},el('span',{textContent:type}),el('div',{},el('i',{style:`width:${n/max*100}%`})),el('b',{textContent:n}))):[empty()]));
 $('shiftNowTitle').textContent=w.shiftNow;$('shiftNow').replaceChildren(shiftOf(state)?shiftFacts(shiftOf(state)):el('p',{class:'hint',textContent:w.noShift}));
 $('recentTitle').textContent=w.recent;const recent=state.tasks.slice(-8).reverse();$('recent').replaceChildren(...(recent.length?recent.map(t=>taskItem(t)):[empty()]))}

function shiftFacts(sh){const w=W[lang];const breaks=sumIntervals(sh.breaks);const after=sh.planned?sumIntervals(sh.intervals,sh.planned):null;
 return el('div',{class:'facts'},...[[w.started,dt(sh.start)],[w.planned,sh.planned?hm(sh.planned):'—'],[w.worked,fmt(sumIntervals(sh.intervals))],[w.breaks,fmt(breaks)],[w.overtime,after==null?'—':fmt(after)]].map(([a,b])=>el('div',{},el('span',{textContent:a}),el('b',{textContent:b}))))}

let preset='today';
function setPreset(p){preset=p;const d=new Date();let from=today();if(p==='week'){d.setDate(d.getDate()-6);from=TaskTime.dateKey(+d)}if(p==='month'){d.setDate(1);from=TaskTime.dateKey(+d)}$('from').value=from;$('to').value=today();drawStats()}
function validRange(){return $('from').value&&$('to').value&&$('from').value<=$('to').value}
function drawStats(){const w=W[lang];$('presets').replaceChildren(...w.presets.map(([k,l])=>el('button',{class:k===preset?'on':'',textContent:l,onclick:()=>setPreset(k)})));
 $('fromLabel').textContent=w.from;$('toLabel').textContent=w.to;$('csv').textContent=w.csv;$('statsNote').textContent=w.statsNote;
 if(!validRange()){message(w.invalid);return}const rows=TaskTime.stats(state,$('from').value,$('to').value).filter(r=>r.count||TaskTime.TYPES.includes(r.type));
 $('head').replaceChildren(el('tr',{},...w.heads.map(h=>el('th',{textContent:h}))));
 $('rows').replaceChildren(...rows.map(r=>el('tr',{class:r.count?'':'zero'},...[r.type,r.count,fmt(r.min),fmt(r.max),fmt(r.avg),fmt(r.total)].map(x=>el('td',{textContent:x})))));
 const n=rows.reduce((a,r)=>a+r.count,0),tot=rows.reduce((a,r)=>a+r.total,0);$('foot').replaceChildren(el('tr',{},...[w.total,n,'','',n?fmt(tot/n):'—',fmt(tot)].map(x=>el('td',{textContent:x}))))}

function drawShifts(){const w=W[lang];const list=[...state.shifts].reverse();$('shifts').replaceChildren(...(list.length?list.map(sh=>el('div',{class:'card shift'},el('div',{class:'head'},el('h3',{textContent:`${dt(sh.start)} → ${sh.end?hm(sh.end):w.open}`}),el('small',{textContent:sh.planned?(sh.overtime?w.otYes:(sh.endChoice?w.otNo:'')):''})),shiftFacts(sh))):[empty()]))}
function drawReview(){const w=W[lang];$('reviewNote').textContent=w.reviewNote;const r=state.tasks.filter(t=>t.status==='review').slice(-200).reverse();$('review').replaceChildren(...(r.length?r.map(t=>taskItem(t,true)):[empty()]))}
const pref=(k,d)=>{try{return localStorage.getItem(k)||d}catch{return d}};const setPref=(k,v)=>{try{localStorage.setItem(k,v)}catch{}};
let hFilter=pref('tt-hfilter','all'),hSize=Number(pref('tt-hsize','25'))||25,hPage=1;
function drawHistory(){const w=W[lang];$('search').placeholder=w.search;const q=$('search').value.trim().toLowerCase();
 $('hFilter').replaceChildren(...w.hFilters.map(([k,l])=>el('button',{class:k===hFilter?'on':'',textContent:l,onclick:()=>{hFilter=k;hPage=1;setPref('tt-hfilter',k);drawHistory()}})));
 $('hSize').dataset.label=w.hSize;$('hSize').replaceChildren(...[25,50,100].map(n=>el('button',{class:n===hSize?'on':'',textContent:n,onclick:()=>{hSize=n;hPage=1;setPref('tt-hsize',String(n));drawHistory()}})));
 const keep={all:()=>true,normal:t=>!t.postQa,postqa:t=>!!t.postQa,review:t=>t.status==='review'}[hFilter]||(()=>true);
 const list=state.tasks.slice().reverse().filter(keep).filter(t=>!q||[t.type,t.league,t.id,t.postQa?'post qa':''].some(x=>String(x||'').toLowerCase().includes(q)));
 const pages=Math.max(1,Math.ceil(list.length/hSize));hPage=Math.min(Math.max(1,hPage),pages);const from=(hPage-1)*hSize,page=list.slice(from,from+hSize);
 $('hInfo').textContent=w.hInfo(from+1,from+page.length,list.length);
 // Day totals use every filtered task of that day, not only the ones on this page.
 const dayTot={};for(const t of list){const k=TaskTime.dateKey(t.start);const d=dayTot[k]||(dayTot[k]={n:0,ms:0});d.n++;d.ms+=t.observedMs||0}
 const out=[];let cur='';for(const t of page){const k=TaskTime.dateKey(t.start);if(k!==cur){cur=k;const d=new Date(t.start);out.push(el('div',{class:'dayhead'},el('b',{textContent:`${w.days[d.getDay()]}, ${d.toLocaleDateString(loc(),{day:'2-digit',month:'2-digit',year:'numeric'}).replace(/\s*г\.$/,'')}`}),el('span',{textContent:w.hDay(dayTot[k].n,short(dayTot[k].ms))})))}out.push(taskItem(t))}
 $('history').replaceChildren(...(out.length?[el('div',{class:'list'},...out)]:[empty()]));
 const go=n=>{hPage=n;drawHistory();$('history').scrollIntoView({block:'start',behavior:'smooth'})};
 const nums=[];for(let i=1;i<=pages;i++)if(i===1||i===pages||Math.abs(i-hPage)<=1)nums.push(i);else if(nums.at(-1)!=='…')nums.push('…');
 $('hPager').replaceChildren(...(pages>1?[el('button',{textContent:w.prev,disabled:hPage===1,onclick:()=>go(hPage-1)}),...nums.map(n=>n==='…'?el('span',{class:'gap',textContent:'…'}):el('button',{class:n===hPage?'on':'',textContent:n,onclick:()=>go(n)})),el('button',{textContent:w.next,disabled:hPage===pages,onclick:()=>go(hPage+1)})]:[]))}

function drawSettings(){const w=W[lang],a=TaskTime.alertSettings(state);for(const id of ['alertTitle','alertNote','dataTitle','dataNote','backup','restore'])$(id).textContent=w[id];$('alertSoundLabel').textContent=w.alertSound;$('alertVolumeLabel').textContent=w.alertVolume;$('alertTest').textContent=w.alertTest;$('alertNotifyLabel').textContent=w.alertNotify;
 drawConfig();$('verTitle').textContent=w.verTitle;$('verNote').textContent=w.verNote(chrome.runtime.getManifest().version);$('verCheck').textContent=w.verCheck;$('notifyTip').textContent=w.notifyTip;$('verHowTitle').textContent=w.verHow;$('verSteps').innerHTML=w.verSteps.map(x=>`<li>${x}</li>`).join('');$('openExt').textContent=w.openExt;$('folderTitle').textContent=w.folderTitle;$('folderNote').textContent=w.folderNote;$('folderInput').placeholder=w.folderPh;$('folderSave').textContent=w.folderSave;$('folderSteps').innerHTML=w.folderSteps.map(x=>`<li>${x}</li>`).join('');drawFolder();$('alertSound').checked=a.sound;$('alertVolume').value=a.volume;volFill();$('alertVolume').disabled=!a.sound;$('alertNotify').checked=a.notify}
async function saveAlert(change){try{state.alert=await request({kind:'alert-settings',alert:{...TaskTime.alertSettings(state),...change}});drawSettings();message(W[lang].saved)}catch(e){message(e.message)}}

const isNewer=(a,b)=>{const x=String(a).split('.').map(Number),y=String(b).split('.').map(Number);for(let i=0;i<Math.max(x.length,y.length);i++){if((x[i]||0)!==(y[i]||0))return (x[i]||0)>(y[i]||0)}return false};
let staleBackground=false;
function drawUpdate(){const w=W[lang],u=state.update&&isNewer(state.update.version,chrome.runtime.getManifest().version)?state.update:null;
 if(staleBackground)return $('update').replaceChildren(el('div',{class:'update'},el('b',{textContent:w.finUpd}),el('span',{textContent:w.finishHow}),el('a',{href:'#',textContent:w.finishGo+' →',onclick:e=>{e.preventDefault();chrome.tabs.create({url:'chrome://extensions/?id='+chrome.runtime.id})}})));
 $('update').replaceChildren(...(u?[el('div',{class:'update'},el('b',{textContent:w.upd(u.version)}),el('span',{textContent:w.updHow}),el('a',{href:u.url,target:'_blank',rel:'noopener',textContent:w.updGo+' →'}))]:[]))}
function draw(){drawChrome();drawUpdate();drawQuestions();({today:drawToday,stats:drawStats,shifts:drawShifts,review:drawReview,history:drawHistory,settings:drawSettings})[tab]()}
async function load(){state=await request({kind:'get'});lang=state.lang||'bg';
 const cur=chrome.runtime.getManifest().version;let build=null;try{build=await request({kind:'build'})}catch{}staleBackground=build!==cur;
 if(state.update&&!isNewer(state.update.version,cur)){state.update=null;try{const st=(await chrome.storage.local.get('tasktime')).tasktime;if(st){st.update=null;await chrome.storage.local.set({tasktime:st})}const b=await chrome.action.getBadgeText({});if(b==='↑')await chrome.action.setBadgeText({text:''})}catch{}}
 draw()}

try{const t=localStorage.getItem('tt-tab');if(TABS.includes(t))tab=t}catch{}
$('from').value=$('to').value=today();$('from').onchange=$('to').onchange=()=>{preset='';drawStats()};
document.querySelectorAll('#lang button').forEach(b=>b.onclick=()=>{if(b.dataset.lang!==lang)mutate({kind:'language',lang:b.dataset.lang})});
const volFill=()=>{const v=$('alertVolume');v.style.setProperty('--p',(v.value*100)+'%');$('alertVolumeOut').textContent=Math.round(v.value*100)+'%'};$('alertVolume').addEventListener('input',volFill);
$('search').oninput=()=>{hPage=1;drawHistory()};
$('csv').onclick=()=>{if(!validRange())return message(W[lang].invalid);const rows=[['type','count','fastest_seconds','slowest_seconds','average_seconds','total_seconds','from','to','timezone'],...TaskTime.stats(state,$('from').value,$('to').value).map(r=>[r.type,r.count,r.min==null?'':r.min/1000,r.max==null?'':r.max/1000,r.avg==null?'':r.avg/1000,r.total/1000,$('from').value,$('to').value,Intl.DateTimeFormat().resolvedOptions().timeZone])];download(`TaskTime-${$('from').value}-${$('to').value}.csv`,'﻿'+rows.map(r=>r.map(v=>'"'+String(v).replaceAll('"','""')+'"').join(',')).join('\r\n'),'text/csv;charset=utf-8')};
$('backup').onclick=()=>download(`TaskTime-backup-${today()}.json`,JSON.stringify(state,null,2),'application/json');
let folder='';chrome.storage.local.get('tasktimeFolder').then(r=>{folder=r.tasktimeFolder||'';if(tab==='settings')drawFolder()}).catch(()=>{});
function drawFolder(){const w=W[lang];$('folderShow').replaceChildren(...(folder?[el('code',{textContent:folder}),el('button',{class:'ghost',textContent:w.folderCopy,onclick:()=>navigator.clipboard.writeText(folder).then(()=>message(w.saved)).catch(()=>{})})]:[el('span',{class:'none',textContent:w.folderNone})]));if(document.activeElement!==$('folderInput'))$('folderInput').value=folder}
$('folderSave').onclick=async()=>{folder=$('folderInput').value.trim().slice(0,500);await chrome.storage.local.set({tasktimeFolder:folder});drawFolder();message(W[lang].saved)};
const openExtensions=()=>chrome.tabs.create({url:'chrome://extensions/?id='+chrome.runtime.id});$('openExt').onclick=openExtensions;
const BUILTIN={types:()=>TaskTime.TYPES,leagues:()=>TaskTime.LEAGUES,pages:()=>TaskTime.PAGES};
async function saveCustom(custom,dismiss){try{state.custom=await request({kind:'custom-config',custom,dismiss});await load();message(W[lang].saved)}catch(e){message(e.message)}}
function drawConfig(){const w=W[lang];$('cfgTitle').textContent=w.cfgTitle;$('cfgNote').textContent=w.cfgNote;const own={leagues:[],types:[],pages:[],...(state.custom||{})},site=state.remote||{};
 const unk=Object.keys(state.unknown||{}).filter(t=>!TaskTime.TYPES.includes(t)&&!(own.types||[]).includes(t)&&!(site.types||[]).includes(t));
 $('cfgUnknown').replaceChildren(...unk.map(t=>el('div',{class:'unknown'},el('b',{textContent:t}),el('span',{textContent:w.cfgUnknown(t)}),el('button',{textContent:w.cfgAddType,onclick:()=>saveCustom({...own,types:[...own.types,t]})}),el('button',{class:'ghost',textContent:w.cfgHide,onclick:()=>saveCustom(own,t)}))));
 $('cfgGroups').replaceChildren(el('div',{class:'legend'},...w.cfgLegend.map((l,i)=>el('span',{},el('i',{class:'tag '+['','site','own'][i],textContent:'abc'}),l))),...['types','leagues','pages'].map(k=>{const input=el('input',{type:'text',placeholder:k==='types'?w.cfgPh:'',spellcheck:false});
  const add=()=>{const v=input.value.trim().toLowerCase();if(!/^[a-z0-9_-]{1,40}$/.test(v))return message(w.cfgBad);if(!own[k].includes(v))saveCustom({...own,[k]:[...own[k],v]})};input.onkeydown=e=>{if(e.key==='Enter')add()};
  const chips=[...BUILTIN[k]().map(v=>el('span',{class:'tag',textContent:v})),...(site[k]||[]).filter(v=>!BUILTIN[k]().includes(v)).map(v=>el('span',{class:'tag site',textContent:v})),...own[k].map(v=>el('span',{class:'tag own'},v,el('button',{textContent:'×',title:'✕',onclick:()=>saveCustom({...own,[k]:own[k].filter(x=>x!==v)})})))];
  return el('div',{class:'cfg'},el('h3',{textContent:w.cfgGroups[k][0]}),el('p',{textContent:w.cfgGroups[k][1]}),el('div',{class:'chips'},...chips),el('div',{class:'addrow'},input,el('button',{class:'ghost',textContent:w.cfgAdd,onclick:add})))}))}
$('verCheck').onclick=async()=>{try{const u=await request({kind:'check-update'});await load();message(u?W[lang].upd(u.version):W[lang].verLatest)}catch(e){message(e.message)}};
$('restore').onclick=()=>$('restoreFile').click();
$('restoreFile').onchange=async()=>{const f=$('restoreFile').files[0];$('restoreFile').value='';if(!f)return;const w=W[lang];let data;try{data=JSON.parse(await f.text())}catch{return message(w.badBackup)}if(!confirm(w.restoreAsk))return;try{const r=await request({kind:'restore',data});await load();message(w.restored(r.tasks,r.shifts))}catch(e){message(e.message==='invalid-backup'?w.badBackup:e.message)}};
$('alertSound').onchange=()=>saveAlert({sound:$('alertSound').checked});$('alertVolume').onchange=()=>saveAlert({volume:Number($('alertVolume').value)});$('alertTest').onclick=()=>request({kind:'test-sound'}).catch(e=>message(e.message));
$('alertNotify').onchange=async()=>{const on=$('alertNotify').checked;if(on){let ok=false;try{ok=await chrome.permissions.request({permissions:['notifications']})}catch{}if(!ok){$('alertNotify').checked=false;return message(W[lang].alertDenied)}}else chrome.permissions.remove({permissions:['notifications']}).catch(()=>{});saveAlert({notify:on})};
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.tasktime){state=changes.tasktime.newValue;lang=state.lang||'bg';if(document.activeElement?.id==='search')return drawChrome();draw()}});
setInterval(()=>{if(state&&tab==='today')drawToday()},30000);
load().catch(e=>message(e.message));
